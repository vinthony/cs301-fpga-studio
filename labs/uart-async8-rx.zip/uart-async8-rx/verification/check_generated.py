#!/usr/bin/env python3
"""Independent absolute-deadline + received-bit-list reference."""
from pathlib import Path
import json,random,subprocess
BASE=Path(__file__).resolve().parents[1];OUT=BASE/'out';OUT.mkdir(exist_ok=True)
class Ref:
 def __init__(self):
  self.first=self.second=1;self.phase=self.timer=self.bit=self.assembly=self.data=self.valid=self.error=self.now=0;self.deadline=None;self.bits=[]
 def pack(self):
  return self.first<<27|self.second<<26|self.phase<<24|self.timer<<21|self.bit<<18|self.assembly<<10|self.data<<2|self.valid<<1|self.error
 def edge(self,raw,sample,clear,reset):
  if clear or reset:self.__init__();return
  if not sample:return
  observed=self.second;self.second=self.first;self.first=raw;self.now+=1;self.valid=self.error=0
  if self.phase==0:
   if observed==0:self.phase=1;self.deadline=self.now+4;self.timer=0
  elif self.now<self.deadline:self.timer=(4 if self.phase==1 else 8)-(self.deadline-self.now)
  elif self.phase==1:
   self.timer=0
   if observed==0:self.phase=2;self.deadline=self.now+8;self.bits=[];self.bit=self.assembly=0
   else:self.phase=0;self.deadline=None
  elif self.phase==2:
   self.bits.append(observed);self.assembly=sum(v*2**i for i,v in enumerate(self.bits));self.timer=0;self.deadline=self.now+8
   if len(self.bits)==8:self.phase=3
   else:self.bit=len(self.bits)
  else:self.timer=0;self.data=sum(v*2**i for i,v in enumerate(self.bits));self.valid=observed;self.error=1-observed;self.phase=0;self.deadline=None
r=Ref();vectors=[]
def add(rx=1,sample=1,clear=0,reset=0):
 before=r.pack();r.edge(rx,sample,clear,reset);after=r.pack();control=rx<<3|sample<<2|clear<<1|reset
 vectors.append(f'{control:x}{before:07x}{after:07x}')
add(reset=1)
for offset in range(8):
 for stop in [0,1]:
  for byte in range(256):
   add(clear=1);events=[]
   levels=[1]*(8+offset)+[v for bit in [0]+[(byte//2**i)%2 for i in range(8)]+[stop] for v in [bit]*8]+[1]*16
   for level in levels:
    add(level)
    if r.valid or r.error:events.append((r.data,r.valid,r.error))
   assert events==[(byte,stop,1-stop)],(byte,stop,offset,events)
for width in range(1,5):
 add(clear=1)
 for raw in [1]*8+[0]*width+[1]*24:add(raw)
 assert r.phase==0 and not r.valid
for period in [7,9]:
 for byte in [0,65,85,170,255]:
  add(clear=1)
  for raw in [1]*8+[v for bit in [0]+[(byte//2**i)%2 for i in range(8)]+[1] for v in [bit]*period]+[1]*24:add(raw)
rng=random.Random(3018)
for i in range(10000):add(rng.randrange(2),int(i%5!=0),int(i%113==0),int(i%271==0))
(OUT/'vectors.hex').write_text('\n'.join(vectors)+'\n')
tb='''module tb;
reg clock=0,reset=0,sample=0,clear=0,rx=1;
wire first,second,valid,error;wire[1:0]phase;wire[2:0]timer,bitIndex;wire[7:0]assembly,data;
wire[27:0]actual={first,second,phase,timer,bitIndex,assembly,data,valid,error};
UARTAsync8RX dut(.clock(clock),.reset(reset),.io_sample(sample),.io_clear(clear),.io_rx(rx),.io_first(first),.io_second(second),.io_phase(phase),.io_timer(timer),.io_bit(bitIndex),.io_assembly(assembly),.io_data(data),.io_valid(valid),.io_error(error));
reg[59:0]vectors[0:COUNT-1];integer i;
initial begin
 $readmemh("vectors.hex",vectors);
 for(i=0;i<COUNT;i=i+1)begin
  {rx,sample,clear,reset}=vectors[i][59:56];#5;
  if(i>0 && actual!==vectors[i][55:28])begin $display("FAIL PRE %0d %h %h",i,actual,vectors[i][55:28]);$fatal;end
  clock=1;#1;
  if(actual!==vectors[i][27:0])begin $display("FAIL POST %0d %h %h",i,actual,vectors[i][27:0]);$fatal;end
  #4;clock=0;
 end
 $display("PASS COUNT edges");$finish;
end
endmodule
'''.replace('COUNT',str(len(vectors)))
(OUT/'tb.v').write_text(tb);subprocess.run(['iverilog','-g2012','-s','tb','-o','sim',str(BASE/'generated/UARTAsync8RX.v'),'tb.v'],cwd=OUT,check=True)
run=subprocess.run(['vvp','sim'],cwd=OUT,text=True,capture_output=True,check=True)
report=dict(status='passed',postEdgeSnapshots=len(vectors),preEdgeSnapshots=len(vectors)-1,packedBits=28,frames=4096,coverage='256 bytes x both stop levels x 8 starting offsets; short pulses 1..4; periods 7/9; 10000 paused/reset random controls',reference='independent Python absolute sample deadlines and received-bit list',stdout=run.stdout.strip())
(BASE/'evidence/generated-rtl-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
