package cs301
import chisel3._
import chisel3.util._
import scala.language.reflectiveCalls
/** One primary clock, sample enables the complete 8x receiver. Numeric model, no metastability. */
class UARTAsync8RX extends Module {
 val io=IO(new Bundle {val sample=Input(Bool());val clear=Input(Bool());val rx=Input(Bool());val first=Output(Bool());val second=Output(Bool());val phase=Output(UInt(2.W));val timer=Output(UInt(3.W));val bit=Output(UInt(3.W));val assembly=Output(UInt(8.W));val data=Output(UInt(8.W));val valid=Output(Bool());val error=Output(Bool())})
 val first=RegInit(true.B);val second=RegInit(true.B);val phase=RegInit(0.U(2.W));val timer=RegInit(0.U(3.W));val bit=RegInit(0.U(3.W));val assembly=RegInit(0.U(8.W));val data=RegInit(0.U(8.W));val valid=RegInit(false.B);val error=RegInit(false.B)
 when(io.clear){first:=true.B;second:=true.B;phase:=0.U;timer:=0.U;bit:=0.U;assembly:=0.U;data:=0.U;valid:=false.B;error:=false.B}
 .elsewhen(io.sample){
  first:=io.rx;second:=first;valid:=false.B;error:=false.B
  switch(phase){
   is(0.U){when(!second){phase:=1.U;timer:=0.U}}
   is(1.U){when(timer===3.U){timer:=0.U;when(!second){phase:=2.U;bit:=0.U;assembly:=0.U}.otherwise{phase:=0.U}}.otherwise{timer:=timer+1.U}}
   is(2.U){when(timer===7.U){timer:=0.U;val mask=(1.U(8.W)<<bit)(7,0);assembly:=(assembly & ~mask) | Mux(second,mask,0.U);when(bit===7.U){phase:=3.U}.otherwise{bit:=bit+1.U}}.otherwise{timer:=timer+1.U}}
   is(3.U){when(timer===7.U){timer:=0.U;data:=assembly;valid:=second;error := !second;phase:=0.U}.otherwise{timer:=timer+1.U}}
  }
 }
 io.first:=first;io.second:=second;io.phase:=phase;io.timer:=timer;io.bit:=bit;io.assembly:=assembly;io.data:=data;io.valid:=valid;io.error:=error
}
