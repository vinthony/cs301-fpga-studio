package cs301
object EmitUARTAsync8RX extends App {
 val path="test_run_dir/UARTAsync8RX_should_receive_every_byte_with_both_stop_levels/UARTAsync8RX.lo.fir"
 require(new java.io.File(path).isFile,"Run test first")
 val file=scala.io.Source.fromFile(path);val source=try file.mkString finally file.close()
 (new firrtl2.stage.FirrtlStage).execute(Array("-X","verilog","--target-dir","generated"),Seq(firrtl2.stage.FirrtlSourceAnnotation(source)))
}
