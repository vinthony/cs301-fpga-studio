package cs301
import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.language.reflectiveCalls
class UARTAsync8RXSpec extends AnyFlatSpec with ChiselScalatestTester {
 behavior of "UARTAsync8RX"
 it should "receive every byte with both stop levels" in {test(new UARTAsync8RX).withAnnotations(Seq(WriteVcdAnnotation)){c=>
  c.clock.setTimeout(30000);c.io.sample.poke(true.B);c.io.clear.poke(false.B);c.io.rx.poke(true.B)
  for(stop<-0 to 1;byte<-0 until 256){
   c.io.clear.poke(true.B);c.clock.step();c.io.clear.poke(false.B)
   val levels=Seq.fill(8)(1)++(Seq(0)++(0 until 8).map(i=>(byte>>i)&1)++Seq(stop)).flatMap(v=>Seq.fill(8)(v))++Seq.fill(16)(1)
   var events=0
   levels.foreach{level=>c.io.rx.poke((level==1).B);c.clock.step();if(c.io.valid.peek().litToBoolean||c.io.error.peek().litToBoolean){events+=1;c.io.data.expect(byte.U);c.io.valid.expect((stop==1).B);c.io.error.expect((stop==0).B)}}
   assert(events==1,s"one complete frame for $byte/$stop")
  }
 }}
 it should "pause all sampled state and clear while paused" in {test(new UARTAsync8RX){c=>
  c.io.sample.poke(true.B);c.io.clear.poke(true.B);c.io.rx.poke(true.B);c.clock.step();c.io.clear.poke(false.B);c.io.rx.poke(false.B);c.clock.step(10)
  val first=c.io.first.peek().litValue;val second=c.io.second.peek().litValue;val phase=c.io.phase.peek().litValue;val timer=c.io.timer.peek().litValue
  c.io.sample.poke(false.B);c.io.rx.poke(true.B);c.clock.step(4);c.io.first.expect((first==1).B);c.io.second.expect((second==1).B);c.io.phase.expect(phase.U);c.io.timer.expect(timer.U)
  c.io.clear.poke(true.B);c.clock.step();c.io.first.expect(true.B);c.io.second.expect(true.B);c.io.phase.expect(0.U);c.io.data.expect(0.U)
 }}
}
