module UARTAsync8RX( // @[src/main/scala/UARTAsync8RX.scala 6:7]
  input        clock, // @[src/main/scala/UARTAsync8RX.scala 6:7]
  input        reset, // @[src/main/scala/UARTAsync8RX.scala 6:7]
  input        io_sample, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  input        io_clear, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  input        io_rx, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output       io_first, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output       io_second, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output [1:0] io_phase, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output [2:0] io_timer, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output [2:0] io_bit, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output [7:0] io_assembly, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output [7:0] io_data, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output       io_valid, // @[src/main/scala/UARTAsync8RX.scala 7:11]
  output       io_error // @[src/main/scala/UARTAsync8RX.scala 7:11]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
  reg [31:0] _RAND_6;
  reg [31:0] _RAND_7;
  reg [31:0] _RAND_8;
`endif // RANDOMIZE_REG_INIT
  reg  first; // @[src/main/scala/UARTAsync8RX.scala 8:19]
  reg  second; // @[src/main/scala/UARTAsync8RX.scala 8:46]
  reg [1:0] phase; // @[src/main/scala/UARTAsync8RX.scala 8:72]
  reg [2:0] timer; // @[src/main/scala/UARTAsync8RX.scala 8:100]
  reg [2:0] bit_; // @[src/main/scala/UARTAsync8RX.scala 8:126]
  reg [7:0] assembly; // @[src/main/scala/UARTAsync8RX.scala 8:157]
  reg [7:0] data; // @[src/main/scala/UARTAsync8RX.scala 8:184]
  reg  valid; // @[src/main/scala/UARTAsync8RX.scala 8:212]
  reg  error; // @[src/main/scala/UARTAsync8RX.scala 8:239]
  wire  _T_1 = ~second; // @[src/main/scala/UARTAsync8RX.scala 13:17]
  wire [1:0] _GEN_0 = ~second ? 2'h1 : phase; // @[src/main/scala/UARTAsync8RX.scala 13:{25,31} 8:72]
  wire [2:0] _GEN_1 = ~second ? 3'h0 : timer; // @[src/main/scala/UARTAsync8RX.scala 13:{25,42} 8:100]
  wire [1:0] _GEN_2 = _T_1 ? 2'h2 : 2'h0; // @[src/main/scala/UARTAsync8RX.scala 14:{105,54,60}]
  wire [2:0] _GEN_3 = _T_1 ? 3'h0 : bit_; // @[src/main/scala/UARTAsync8RX.scala 14:{54,69} 8:126]
  wire [7:0] _GEN_4 = _T_1 ? 8'h0 : assembly; // @[src/main/scala/UARTAsync8RX.scala 14:{54,83} 8:157]
  wire [2:0] _timer_T_1 = timer + 3'h1; // @[src/main/scala/UARTAsync8RX.scala 14:135]
  wire [2:0] _GEN_5 = timer == 3'h3 ? 3'h0 : _timer_T_1; // @[src/main/scala/UARTAsync8RX.scala 14:{128,29,35}]
  wire [1:0] _GEN_6 = timer == 3'h3 ? _GEN_2 : phase; // @[src/main/scala/UARTAsync8RX.scala 14:29 8:72]
  wire [2:0] _GEN_7 = timer == 3'h3 ? _GEN_3 : bit_; // @[src/main/scala/UARTAsync8RX.scala 14:29 8:126]
  wire [7:0] _GEN_8 = timer == 3'h3 ? _GEN_4 : assembly; // @[src/main/scala/UARTAsync8RX.scala 14:29 8:157]
  wire  _T_6 = timer == 3'h7; // @[src/main/scala/UARTAsync8RX.scala 15:22]
  wire [14:0] _mask_T = 15'h1 << bit_; // @[src/main/scala/UARTAsync8RX.scala 15:59]
  wire [7:0] mask = _mask_T[7:0]; // @[src/main/scala/UARTAsync8RX.scala 15:65]
  wire [7:0] _assembly_T = ~mask; // @[src/main/scala/UARTAsync8RX.scala 15:93]
  wire [7:0] _assembly_T_1 = assembly & _assembly_T; // @[src/main/scala/UARTAsync8RX.scala 15:91]
  wire [7:0] _assembly_T_2 = second ? mask : 8'h0; // @[src/main/scala/UARTAsync8RX.scala 15:105]
  wire [7:0] _assembly_T_3 = _assembly_T_1 | _assembly_T_2; // @[src/main/scala/UARTAsync8RX.scala 15:100]
  wire [2:0] _bit_T_1 = bit_ + 3'h1; // @[src/main/scala/UARTAsync8RX.scala 15:169]
  wire [1:0] _GEN_9 = bit_ == 3'h7 ? 2'h3 : phase; // @[src/main/scala/UARTAsync8RX.scala 15:{138,144} 8:72]
  wire [2:0] _GEN_10 = bit_ == 3'h7 ? bit_ : _bit_T_1; // @[src/main/scala/UARTAsync8RX.scala 15:138 8:126 15:164]
  wire [2:0] _GEN_11 = timer == 3'h7 ? 3'h0 : _timer_T_1; // @[src/main/scala/UARTAsync8RX.scala 15:{191,29,35}]
  wire [7:0] _GEN_12 = timer == 3'h7 ? _assembly_T_3 : assembly; // @[src/main/scala/UARTAsync8RX.scala 15:{29,79} 8:157]
  wire [1:0] _GEN_13 = timer == 3'h7 ? _GEN_9 : phase; // @[src/main/scala/UARTAsync8RX.scala 15:29 8:72]
  wire [2:0] _GEN_14 = timer == 3'h7 ? _GEN_10 : bit_; // @[src/main/scala/UARTAsync8RX.scala 15:29 8:126]
  wire [7:0] _GEN_16 = _T_6 ? assembly : data; // @[src/main/scala/UARTAsync8RX.scala 16:{29,45} 8:184]
  wire  _GEN_17 = _T_6 & second; // @[src/main/scala/UARTAsync8RX.scala 16:29 11:35 16:61]
  wire  _GEN_18 = _T_6 & _T_1; // @[src/main/scala/UARTAsync8RX.scala 16:29 11:50 16:76]
  wire [1:0] _GEN_19 = _T_6 ? 2'h0 : phase; // @[src/main/scala/UARTAsync8RX.scala 16:{29,92} 8:72]
  wire [2:0] _GEN_20 = 2'h3 == phase ? _GEN_11 : timer; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:100]
  wire [7:0] _GEN_21 = 2'h3 == phase ? _GEN_16 : data; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:184]
  wire [1:0] _GEN_24 = 2'h3 == phase ? _GEN_19 : phase; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:72]
  wire [2:0] _GEN_25 = 2'h2 == phase ? _GEN_11 : _GEN_20; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [7:0] _GEN_26 = 2'h2 == phase ? _GEN_12 : assembly; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:157]
  wire [1:0] _GEN_27 = 2'h2 == phase ? _GEN_13 : _GEN_24; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [2:0] _GEN_28 = 2'h2 == phase ? _GEN_14 : bit_; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:126]
  wire [7:0] _GEN_29 = 2'h2 == phase ? data : _GEN_21; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:184]
  wire  _GEN_30 = 2'h2 == phase ? 1'h0 : 2'h3 == phase & _GEN_17; // @[src/main/scala/UARTAsync8RX.scala 12:16 11:35]
  wire  _GEN_31 = 2'h2 == phase ? 1'h0 : 2'h3 == phase & _GEN_18; // @[src/main/scala/UARTAsync8RX.scala 12:16 11:50]
  wire [2:0] _GEN_32 = 2'h1 == phase ? _GEN_5 : _GEN_25; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [1:0] _GEN_33 = 2'h1 == phase ? _GEN_6 : _GEN_27; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [2:0] _GEN_34 = 2'h1 == phase ? _GEN_7 : _GEN_28; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [7:0] _GEN_35 = 2'h1 == phase ? _GEN_8 : _GEN_26; // @[src/main/scala/UARTAsync8RX.scala 12:16]
  wire [7:0] _GEN_36 = 2'h1 == phase ? data : _GEN_29; // @[src/main/scala/UARTAsync8RX.scala 12:16 8:184]
  wire  _GEN_37 = 2'h1 == phase ? 1'h0 : _GEN_30; // @[src/main/scala/UARTAsync8RX.scala 12:16 11:35]
  wire  _GEN_38 = 2'h1 == phase ? 1'h0 : _GEN_31; // @[src/main/scala/UARTAsync8RX.scala 12:16 11:50]
  wire  _GEN_46 = io_sample ? io_rx : first; // @[src/main/scala/UARTAsync8RX.scala 10:22 11:8 8:19]
  wire  _GEN_47 = io_sample ? first : second; // @[src/main/scala/UARTAsync8RX.scala 10:22 11:22 8:46]
  wire  _GEN_55 = io_clear | _GEN_46; // @[src/main/scala/UARTAsync8RX.scala 9:{16,22}]
  wire  _GEN_56 = io_clear | _GEN_47; // @[src/main/scala/UARTAsync8RX.scala 9:{16,37}]
  assign io_first = first; // @[src/main/scala/UARTAsync8RX.scala 19:10]
  assign io_second = second; // @[src/main/scala/UARTAsync8RX.scala 19:27]
  assign io_phase = phase; // @[src/main/scala/UARTAsync8RX.scala 19:44]
  assign io_timer = timer; // @[src/main/scala/UARTAsync8RX.scala 19:60]
  assign io_bit = bit_; // @[src/main/scala/UARTAsync8RX.scala 19:74]
  assign io_assembly = assembly; // @[src/main/scala/UARTAsync8RX.scala 19:91]
  assign io_data = data; // @[src/main/scala/UARTAsync8RX.scala 19:109]
  assign io_valid = valid; // @[src/main/scala/UARTAsync8RX.scala 19:124]
  assign io_error = error; // @[src/main/scala/UARTAsync8RX.scala 19:140]
  always @(posedge clock) begin
    first <= reset | _GEN_55; // @[src/main/scala/UARTAsync8RX.scala 8:{19,19}]
    second <= reset | _GEN_56; // @[src/main/scala/UARTAsync8RX.scala 8:{46,46}]
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{72,72}]
      phase <= 2'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{16,51}]
      phase <= 2'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:72]
      if (2'h0 == phase) begin // @[src/main/scala/UARTAsync8RX.scala 12:16]
        phase <= _GEN_0;
      end else begin
        phase <= _GEN_33;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{100,100}]
      timer <= 3'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{16,62}]
      timer <= 3'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:100]
      if (2'h0 == phase) begin // @[src/main/scala/UARTAsync8RX.scala 12:16]
        timer <= _GEN_1;
      end else begin
        timer <= _GEN_32;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{126,126}]
      bit_ <= 3'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{16,71}]
      bit_ <= 3'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:126]
      if (!(2'h0 == phase)) begin // @[src/main/scala/UARTAsync8RX.scala 12:16 8:126]
        bit_ <= _GEN_34;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{157,157}]
      assembly <= 8'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{16,85}]
      assembly <= 8'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:157]
      if (!(2'h0 == phase)) begin // @[src/main/scala/UARTAsync8RX.scala 12:16 8:157]
        assembly <= _GEN_35;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{184,184}]
      data <= 8'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{16,95}]
      data <= 8'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:184]
      if (!(2'h0 == phase)) begin // @[src/main/scala/UARTAsync8RX.scala 12:16 8:184]
        data <= _GEN_36;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{212,212}]
      valid <= 1'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{106,16}]
      valid <= 1'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:212]
      if (2'h0 == phase) begin // @[src/main/scala/UARTAsync8RX.scala 12:16 11:35]
        valid <= 1'h0;
      end else begin
        valid <= _GEN_37;
      end
    end
    if (reset) begin // @[src/main/scala/UARTAsync8RX.scala 8:{239,239}]
      error <= 1'h0;
    end else if (io_clear) begin // @[src/main/scala/UARTAsync8RX.scala 9:{121,16}]
      error <= 1'h0;
    end else if (io_sample) begin // @[src/main/scala/UARTAsync8RX.scala 10:22 8:239]
      if (2'h0 == phase) begin // @[src/main/scala/UARTAsync8RX.scala 12:16 11:50]
        error <= 1'h0;
      end else begin
        error <= _GEN_38;
      end
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  first = _RAND_0[0:0];
  _RAND_1 = {1{`RANDOM}};
  second = _RAND_1[0:0];
  _RAND_2 = {1{`RANDOM}};
  phase = _RAND_2[1:0];
  _RAND_3 = {1{`RANDOM}};
  timer = _RAND_3[2:0];
  _RAND_4 = {1{`RANDOM}};
  bit_ = _RAND_4[2:0];
  _RAND_5 = {1{`RANDOM}};
  assembly = _RAND_5[7:0];
  _RAND_6 = {1{`RANDOM}};
  data = _RAND_6[7:0];
  _RAND_7 = {1{`RANDOM}};
  valid = _RAND_7[0:0];
  _RAND_8 = {1{`RANDOM}};
  error = _RAND_8[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
