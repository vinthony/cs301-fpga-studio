# GBU-CS301：两级采样与8倍UART接收硬件参考

此工程对应教学板 `asyncrx` 页面。包含 Chisel 源码、生成 Verilog、测试、VCD 和独立复验脚本。

## 接口约定

- `clock` 为唯一主时钟。`sample=1` 的边沿推进一次接收器8倍采样，`sample=0` 时包括两级寄存器、计数及事件在内的全部状态保持。
- `clear` 或模块同步 `reset` 优先采样使能：两级值初始化为1，IDLE，计时/位号/组装/完成字节/事件清零。
- 状态机读取边沿前的 `second`。本边沿 `first` 采 `rx`，`second` 采旧 `first`；不会直接读新值。
- IDLE检测低后等待4次采样确认起始中心；随后每8次采样获取一个数据位，低位先收，最后检查停止位。
- `assembly` 为正在组装的值；`data` 仅在停止位采样时更新（错误帧也更新，必须检查valid/error）。
- `valid` 或 `error` 维持到下一个有效sample边沿；若sample暂停，事件也保持。下游不能把每个主时钟都当作新字节。
- `phase`: 0 IDLE，1 START，2 DATA，3 STOP。`timer`、`bit`及两级值作为教学调试输出。

## 运行

需要JDK17/21；脚本下载并校验本工程本地sbt启动器，不修改全局环境。

```sh
chmod +x run.sh
./run.sh test 'Test / runMain cs301.EmitUARTAsync8RX'
python3 verification/check_generated.py
```

第二步需要PATH中有Icarus Verilog的`iverilog`与`vvp`。独立参考使用绝对采样时刻的截止期限和“已收到位列表”，不是把Chisel或网页状态转移复制成Python。它重新生成输入向量并对实际生成RTL的28位状态在边沿前后比较。

网页对照脚本在教学板主工程 `tests/uart_async8_rtl_match.cjs`：

```sh
node tests/uart_async8_rtl_match.cjs /path/to/uart-async8-rx/out/vectors.hex
```

`out`由复验生成，不随下载包提供。VCD在`evidence/UARTAsync8RX.vcd`，由512组全部字节/两种停止位的Chisel测试产生。Verilog由测试后的`.lo.fir`经JVM FIRRTL后端导出，不需要本机firtool。

## 已验证范围

- 两项Chisel测试：全部256字节×正确/错误停止位；暂停保持及暂停时清零。
- 独立RTL参考4096帧：256字节×两种停止位×8种起始前空闲长度；1…4采样低脉冲；发送每位7/9采样的有限例子；10000步暂停/复位随机输入。
- 455689边沿后、455688边沿前的28位全状态快照通过。
- 网页使用同一独立参考向量，通过911377项状态比较。sample=0映射为不调用网页采样；clear/reset映射为接收器初始化，不比较暂停墙钟时间。

## 边界

这是数字功能参考，不是实体串口验证。两级值仅在sample边沿更新；没有模拟亚稳态、MTBF、输入模拟噪声或表决采样，也没有厂商同步器属性。8种起始前空闲长度不证明亚采样周期的物理相位容差。有限7/9采样例子不构成任意波特率偏差容限。

本包不含主时钟到8倍采样的分频器、UART TX、FIFO、完整SoC、板级引脚约束、STA或资源/Fmax报告。与FIFO收发链尚未完成硬件集成。教学板中的GBU-CS301为教学命名，不代表已验证的实体板型号。
