#!/usr/bin/env python3
"""Independent prefix quotient/remainder formulas, including next-state candidates."""
from pathlib import Path
import json,random,subprocess
BASE=Path(__file__).resolve().parents[1];OUT=BASE/'out';OUT.mkdir(exist_ok=True)
a=d=k=0;loaded=False;vectors=[]
def state():
 if loaded and d:
  prefix=a//2**(4-k);q=((a*2**k)&15)|(prefix//d);r=prefix%d
 else:q=a;r=0
 zero=loaded and d==0;active=loaded and not zero and k<4;done=loaded and (zero or k==4);valid=loaded and not zero and k==4
 shifted=r*2+q//8;trial=(shifted-d)%32;borrow=shifted<d
 if active:
  prefix=a//2**(3-k);nextq=((a*2**(k+1))&15)|(prefix//d);nextr=prefix%d
 else:nextq=q;nextr=r
 return [(q,4),(r,4),(d,4),(k,3),(loaded,1),(zero,1),(active,1),(done,1),(valid,1),(shifted,5),(trial,5),(borrow,1),(nextq,4),(nextr,4)]
def pack():
 value=0
 for field,width in state():value=value*2**width+int(field)
 return value
def add(x=0,y=0,step=0,load=0,clear=0,reset=0):
 global a,d,k,loaded
 before=pack()
 if clear or reset:a=d=k=0;loaded=False
 elif load:a=x;d=y;k=0;loaded=True
 elif step and loaded and d and k<4:k+=1
 after=pack();control=x<<12|y<<8|reset<<3|clear<<2|load<<1|step
 vectors.append(f'{control:04x}{before:010x}{after:010x}')
add(reset=1)
for phase in [-2,-1,0,1,2,3,4]:
 for controls in range(16):
  add(clear=1)
  if phase!=-1:
   add(x=13,y=0 if phase==-2 else 3,load=1)
   for _ in range(max(0,phase)):add(step=1)
  add(x=7,y=5,step=controls&1,load=(controls>>1)&1,clear=(controls>>2)&1,reset=(controls>>3)&1)
for x in range(16):
 for y in range(16):
  add(x=x,y=y,load=1)
  for _ in range(4):add(x=15-x,y=0,step=0);add(step=1)
  add(step=1);add(step=0)
rng=random.Random(3015)
for i in range(20000):add(rng.randrange(16),rng.randrange(16),rng.randrange(2),int(i%11==0),int(i%113==0),int(i%271==0))
(OUT/'vectors.hex').write_text('\n'.join(vectors)+'\n')
tb='''module tb;
reg clock=0,reset=0,step=0,load=0,clear=0;reg[3:0]a=0,b=0;
wire[3:0]q,r,divisor,nextQ,nextR;wire[2:0]rounds;wire loaded,zero,busy,done,valid,borrow;wire[4:0]shifted,trial;
wire[39:0]actual={1'b0,q,r,divisor,rounds,loaded,zero,busy,done,valid,shifted,trial,borrow,nextQ,nextR};
RestoreDivide4 dut(.clock(clock),.reset(reset),.io_clear(clear),.io_load(load),.io_step(step),.io_a(a),.io_b(b),.io_q(q),.io_r(r),.io_divisor(divisor),.io_rounds(rounds),.io_loaded(loaded),.io_zero(zero),.io_busy(busy),.io_done(done),.io_valid(valid),.io_shifted(shifted),.io_trial(trial),.io_borrow(borrow),.io_nextQ(nextQ),.io_nextR(nextR));
reg[95:0]vectors[0:COUNT-1];integer i;
initial begin
 $readmemh("vectors.hex",vectors);
 for(i=0;i<COUNT;i=i+1)begin
  a=vectors[i][95:92];b=vectors[i][91:88];{reset,clear,load,step}=vectors[i][83:80];#5;
  if(i>0 && actual!==vectors[i][79:40])begin $display("FAIL PRE %0d %h %h",i,actual,vectors[i][79:40]);$fatal;end
  clock=1;#1;
  if(actual!==vectors[i][39:0])begin $display("FAIL POST %0d %h %h",i,actual,vectors[i][39:0]);$fatal;end
  #4;clock=0;
 end
 $display("PASS COUNT edges");$finish;
end
endmodule
'''.replace('COUNT',str(len(vectors)))
(OUT/'tb.v').write_text(tb);subprocess.run(['iverilog','-g2012','-s','tb','-o','sim',str(BASE/'generated/RestoreDivide4.v'),'tb.v'],cwd=OUT,check=True)
run=subprocess.run(['vvp','sim'],cwd=OUT,text=True,capture_output=True,check=True)
report=dict(status='passed',postEdgeSnapshots=len(vectors),preEdgeSnapshots=len(vectors)-1,packedBits=39,inputPairs=256,coverage='all input pairs including zero; 7 saved stages x 16 controls; paused inputs, done hold and 20000 random controls',reference='closed-form quotient/remainder of original dividend prefixes, including next prefix candidates',stdout=run.stdout.strip())
(BASE/'evidence/generated-rtl-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
