module RestoreDivide4( // @[src/main/scala/RestoreDivide4.scala 6:7]
  input        clock, // @[src/main/scala/RestoreDivide4.scala 6:7]
  input        reset, // @[src/main/scala/RestoreDivide4.scala 6:7]
  input        io_clear, // @[src/main/scala/RestoreDivide4.scala 7:11]
  input        io_load, // @[src/main/scala/RestoreDivide4.scala 7:11]
  input        io_step, // @[src/main/scala/RestoreDivide4.scala 7:11]
  input  [3:0] io_a, // @[src/main/scala/RestoreDivide4.scala 7:11]
  input  [3:0] io_b, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [3:0] io_q, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [3:0] io_r, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [3:0] io_divisor, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [2:0] io_rounds, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_loaded, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_zero, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_busy, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_done, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_valid, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [4:0] io_shifted, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [4:0] io_trial, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output       io_borrow, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [3:0] io_nextQ, // @[src/main/scala/RestoreDivide4.scala 7:11]
  output [3:0] io_nextR // @[src/main/scala/RestoreDivide4.scala 7:11]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
  reg [31:0] _RAND_5;
`endif // RANDOMIZE_REG_INIT
  reg [3:0] q; // @[src/main/scala/RestoreDivide4.scala 8:15]
  reg [3:0] r; // @[src/main/scala/RestoreDivide4.scala 8:39]
  reg [3:0] divisor; // @[src/main/scala/RestoreDivide4.scala 8:69]
  reg [2:0] rounds; // @[src/main/scala/RestoreDivide4.scala 8:98]
  reg  loaded; // @[src/main/scala/RestoreDivide4.scala 8:127]
  reg  zero; // @[src/main/scala/RestoreDivide4.scala 8:153]
  wire  _active_T_1 = loaded & ~zero; // @[src/main/scala/RestoreDivide4.scala 9:20]
  wire  active = loaded & ~zero & rounds < 3'h4; // @[src/main/scala/RestoreDivide4.scala 9:29]
  wire [4:0] shifted = {r,q[3]}; // @[src/main/scala/RestoreDivide4.scala 10:17]
  wire [5:0] _difference_T = {1'h0,r,q[3]}; // @[src/main/scala/RestoreDivide4.scala 10:44]
  wire [5:0] _difference_T_1 = {2'h0,divisor}; // @[src/main/scala/RestoreDivide4.scala 10:66]
  wire [5:0] difference = _difference_T - _difference_T_1; // @[src/main/scala/RestoreDivide4.scala 10:62]
  wire  borrow = difference[5]; // @[src/main/scala/RestoreDivide4.scala 10:106]
  wire [4:0] trial = difference[4:0]; // @[src/main/scala/RestoreDivide4.scala 10:130]
  wire  _nextQ_T_1 = ~borrow; // @[src/main/scala/RestoreDivide4.scala 11:34]
  wire [3:0] _nextQ_T_2 = {q[2:0],_nextQ_T_1}; // @[src/main/scala/RestoreDivide4.scala 11:26]
  wire [3:0] nextQ = active ? _nextQ_T_2 : q; // @[src/main/scala/RestoreDivide4.scala 11:15]
  wire [3:0] _nextR_T_2 = borrow ? shifted[3:0] : trial[3:0]; // @[src/main/scala/RestoreDivide4.scala 11:70]
  wire [3:0] nextR = active ? _nextR_T_2 : r; // @[src/main/scala/RestoreDivide4.scala 11:59]
  wire [2:0] _rounds_T_1 = rounds + 3'h1; // @[src/main/scala/RestoreDivide4.scala 14:63]
  wire  _GEN_7 = io_load | loaded; // @[src/main/scala/RestoreDivide4.scala 13:{20,68} 8:127]
  assign io_q = q; // @[src/main/scala/RestoreDivide4.scala 15:6]
  assign io_r = r; // @[src/main/scala/RestoreDivide4.scala 15:14]
  assign io_divisor = divisor; // @[src/main/scala/RestoreDivide4.scala 15:28]
  assign io_rounds = rounds; // @[src/main/scala/RestoreDivide4.scala 15:47]
  assign io_loaded = loaded; // @[src/main/scala/RestoreDivide4.scala 15:65]
  assign io_zero = zero; // @[src/main/scala/RestoreDivide4.scala 15:81]
  assign io_busy = loaded & ~zero & rounds < 3'h4; // @[src/main/scala/RestoreDivide4.scala 9:29]
  assign io_done = loaded & (zero | rounds == 3'h4); // @[src/main/scala/RestoreDivide4.scala 15:120]
  assign io_valid = _active_T_1 & rounds == 3'h4; // @[src/main/scala/RestoreDivide4.scala 15:172]
  assign io_shifted = {r,q[3]}; // @[src/main/scala/RestoreDivide4.scala 10:17]
  assign io_trial = difference[4:0]; // @[src/main/scala/RestoreDivide4.scala 10:130]
  assign io_borrow = difference[5]; // @[src/main/scala/RestoreDivide4.scala 10:106]
  assign io_nextQ = active ? _nextQ_T_2 : q; // @[src/main/scala/RestoreDivide4.scala 11:15]
  assign io_nextR = active ? _nextR_T_2 : r; // @[src/main/scala/RestoreDivide4.scala 11:59]
  always @(posedge clock) begin
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{15,15}]
      q <= 4'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,18}]
      q <= 4'h0;
    end else if (io_load) begin // @[src/main/scala/RestoreDivide4.scala 13:{20,22}]
      q <= io_a;
    end else if (io_step & active) begin // @[src/main/scala/RestoreDivide4.scala 14:30]
      q <= nextQ; // @[src/main/scala/RestoreDivide4.scala 14:32]
    end
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{39,39}]
      r <= 4'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,25}]
      r <= 4'h0;
    end else if (io_load) begin // @[src/main/scala/RestoreDivide4.scala 13:{20,30}]
      r <= 4'h0;
    end else if (io_step & active) begin // @[src/main/scala/RestoreDivide4.scala 14:30]
      r <= nextR; // @[src/main/scala/RestoreDivide4.scala 14:41]
    end
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{69,69}]
      divisor <= 4'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,38}]
      divisor <= 4'h0;
    end else if (io_load) begin // @[src/main/scala/RestoreDivide4.scala 13:20]
      divisor <= io_b; // @[src/main/scala/RestoreDivide4.scala 13:43]
    end
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{98,98}]
      rounds <= 3'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,50}]
      rounds <= 3'h0;
    end else if (io_load) begin // @[src/main/scala/RestoreDivide4.scala 13:{20,56}]
      rounds <= 3'h0;
    end else if (io_step & active) begin // @[src/main/scala/RestoreDivide4.scala 14:30]
      rounds <= _rounds_T_1; // @[src/main/scala/RestoreDivide4.scala 14:55]
    end
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{127,127}]
      loaded <= 1'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,62}]
      loaded <= 1'h0;
    end else begin
      loaded <= _GEN_7;
    end
    if (reset) begin // @[src/main/scala/RestoreDivide4.scala 8:{153,153}]
      zero <= 1'h0;
    end else if (io_clear) begin // @[src/main/scala/RestoreDivide4.scala 12:{16,76}]
      zero <= 1'h0;
    end else if (io_load) begin // @[src/main/scala/RestoreDivide4.scala 13:20]
      zero <= io_b == 4'h0; // @[src/main/scala/RestoreDivide4.scala 13:81]
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  q = _RAND_0[3:0];
  _RAND_1 = {1{`RANDOM}};
  r = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  divisor = _RAND_2[3:0];
  _RAND_3 = {1{`RANDOM}};
  rounds = _RAND_3[2:0];
  _RAND_4 = {1{`RANDOM}};
  loaded = _RAND_4[0:0];
  _RAND_5 = {1{`RANDOM}};
  zero = _RAND_5[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
