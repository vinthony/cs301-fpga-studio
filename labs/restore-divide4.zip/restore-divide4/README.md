# GBU-CS301：四位无符号恢复除法

对应教学板divide4页面；四位被除数/除数、四轮商余数保存、五位临时试减。包内包含Chisel、生成Verilog、两项测试、波形和独立数学复验。

## 主时钟接口约定

同步reset/clear最高优先，清空Q/R/D/轮数/loaded/zero。load次优先，可重启忙中运算：Q捕获被除数、D捕获除数、R=0、轮数=0、loaded=true。

step在loaded且除数非零且轮数<4时提交一次Q/R/轮数；step=0保持。完成后继续step不改写结果；done保持至下一次load/clear。

busy表示仍有可执行轮次。非零除法完成时done=1且valid=1；除数为0时done=1、zero=1、valid=0，Q保留装载被除数、R保持0，不执行轮次。除零无有效商余数；这个教学错误语义**不是RV32 DIVU语义**。

Q在运算中同时含待移入被除数位与已生成商段，不能提前当最终商。每轮R先移入Q最高位，用六位扩展减法计算借位及低五位trial；借位时恢复移入后原值，否则保留差。Q/R/轮数同一个边沿提交。

shifted、trial、borrow、nextQ、nextR都是组合值，可在边沿前变化，不等于已保存。完成或除零时nextQ/nextR保持；shifted/trial/borrow仍显示当前寄存器对应的组合计算，但不会被step写回。

## 运行

需要JDK17/21；启动器按SHA校验下载到工程内部，不修改全局环境。

```sh
chmod +x run.sh
./run.sh test 'Test / runMain cs301.EmitRestoreDivide4'
python3 verification/check_generated.py
```

Python复验依赖Icarus Verilog的iverilog/vvp。Verilog由实际测试lo.fir经JVM FIRRTL后端导出，不依赖本机firtool。VCD位于evidence/RestoreDivide4.vcd。

## 独立验证

参考不复制恢复除法迭代，而根据原被除数前缀直接求商余数：第k轮prefix=floor(A/2^(4-k))，R=prefix mod D，Q=((A×2^k) mod16) OR floor(prefix/D)。下一候选也使用第k+1个前缀直接计算。

生成RTL通过23297边沿后、23296边沿前39位快照：Q/R/D/轮数/loaded/zero/busy/done/valid以及shifted/trial/borrow/nextQ/nextR。覆盖全部256输入组合（含全部16个除零输入）、7种保存阶段×16种控制优先级、20000随机控制、暂停输入变化与完成保持。

网页使用相同参考向量通过46593项，主教学板工程运行：

```sh
node tests/divide4_rtl_match.cjs /path/to/restore-divide4/out/vectors.hex
```

out在复验时生成，不放入包内。step=0映射为网页不推进轮次；网页前三个动画阶段只观察，第四阶段才对应真实step。不比较暂停墙钟时间。

## 范围

四位无符号教学电路；没有有符号除法、参数化任意位宽、CPU M扩展、实体板引脚/时序约束、STA、资源/Fmax或DSP映射验证。普通除法的余数在每轮均小于非零除数，因此被选余数可保存在四位R；试减本身仍保留五位与单独借位，不能把负差编码当作有效余数。
