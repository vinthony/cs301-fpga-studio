package cs301
import chisel3._
import chisel3.util._
import scala.language.reflectiveCalls
/** Four unsigned restoring rounds. Divide by zero is a teaching error, not ISA DIVU semantics. */
class RestoreDivide4 extends Module {
 val io=IO(new Bundle{val clear=Input(Bool());val load=Input(Bool());val step=Input(Bool());val a=Input(UInt(4.W));val b=Input(UInt(4.W));val q=Output(UInt(4.W));val r=Output(UInt(4.W));val divisor=Output(UInt(4.W));val rounds=Output(UInt(3.W));val loaded=Output(Bool());val zero=Output(Bool());val busy=Output(Bool());val done=Output(Bool());val valid=Output(Bool());val shifted=Output(UInt(5.W));val trial=Output(UInt(5.W));val borrow=Output(Bool());val nextQ=Output(UInt(4.W));val nextR=Output(UInt(4.W))})
 val q=RegInit(0.U(4.W));val r=RegInit(0.U(4.W));val divisor=RegInit(0.U(4.W));val rounds=RegInit(0.U(3.W));val loaded=RegInit(false.B);val zero=RegInit(false.B)
 val active=loaded && !zero && rounds<4.U
 val shifted=Cat(r,q(3));val difference=Cat(0.U(1.W),shifted)-Cat(0.U(2.W),divisor);val borrow=difference(5);val trial=difference(4,0)
 val nextQ=Mux(active,Cat(q(2,0),!borrow),q);val nextR=Mux(active,Mux(borrow,shifted(3,0),trial(3,0)),r)
 when(io.clear){q:=0.U;r:=0.U;divisor:=0.U;rounds:=0.U;loaded:=false.B;zero:=false.B}
 .elsewhen(io.load){q:=io.a;r:=0.U;divisor:=io.b;rounds:=0.U;loaded:=true.B;zero:=io.b===0.U}
 .elsewhen(io.step && active){q:=nextQ;r:=nextR;rounds:=rounds+1.U}
 io.q:=q;io.r:=r;io.divisor:=divisor;io.rounds:=rounds;io.loaded:=loaded;io.zero:=zero;io.busy:=active;io.done:=loaded && (zero || rounds===4.U);io.valid:=loaded && !zero && rounds===4.U;io.shifted:=shifted;io.trial:=trial;io.borrow:=borrow;io.nextQ:=nextQ;io.nextR:=nextR
}
