package cs301
import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.language.reflectiveCalls
class RestoreDivide4Spec extends AnyFlatSpec with ChiselScalatestTester {
 behavior of "RestoreDivide4"
 it should "check all divisions and each prefix invariant" in {test(new RestoreDivide4).withAnnotations(Seq(WriteVcdAnnotation)){c=>
  c.io.clear.poke(false.B);c.io.load.poke(false.B);c.io.step.poke(false.B);c.io.a.poke(0.U);c.io.b.poke(0.U)
  for(a<-0 until 16;d<-1 until 16){
   c.io.a.poke(a.U);c.io.b.poke(d.U);c.io.load.poke(true.B);c.clock.step();c.io.load.poke(false.B)
   for(k<-0 to 4){val prefix=a>>(4-k);val quotient=((a<<k)&15)|(prefix/d)
    c.io.q.expect(quotient.U);c.io.r.expect((prefix%d).U);c.io.divisor.expect(d.U);c.io.rounds.expect(k.U);c.io.busy.expect((k<4).B);c.io.done.expect((k==4).B);c.io.valid.expect((k==4).B)
    c.io.a.poke((15-a).U);c.io.b.poke(0.U);c.io.step.poke(false.B);c.clock.step();c.io.rounds.expect(k.U)
    if(k<4){c.io.step.poke(true.B);c.clock.step()}
   }
   c.io.step.poke(true.B);c.clock.step(2);c.io.q.expect((a/d).U);c.io.r.expect((a%d).U);c.io.rounds.expect(4.U)
  }
 }}
 it should "reject zero and honor restart clear priorities" in {test(new RestoreDivide4){c=>
  c.io.a.poke(13.U);c.io.b.poke(0.U);c.io.clear.poke(false.B);c.io.load.poke(true.B);c.io.step.poke(true.B);c.clock.step();c.io.zero.expect(true.B);c.io.done.expect(true.B);c.io.valid.expect(false.B);c.io.q.expect(13.U)
  c.io.load.poke(false.B);c.clock.step(3);c.io.rounds.expect(0.U);c.io.q.expect(13.U)
  c.io.b.poke(3.U);c.io.load.poke(true.B);c.clock.step();c.io.zero.expect(false.B);c.io.q.expect(13.U);c.io.r.expect(0.U);c.io.rounds.expect(0.U)
  c.io.load.poke(false.B);c.clock.step();c.io.r.expect(1.U);c.io.q.expect(10.U)
  c.io.load.poke(true.B);c.io.clear.poke(true.B);c.clock.step();c.io.loaded.expect(false.B);c.io.zero.expect(false.B);c.io.done.expect(false.B);c.io.valid.expect(false.B);c.io.q.expect(0.U)
 }}
}
