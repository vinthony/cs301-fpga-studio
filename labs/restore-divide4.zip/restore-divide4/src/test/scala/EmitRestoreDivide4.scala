package cs301
object EmitRestoreDivide4 extends App {
 val path="test_run_dir/RestoreDivide4_should_check_all_divisions_and_each_prefix_invariant/RestoreDivide4.lo.fir"
 require(new java.io.File(path).isFile,"Run test first")
 val file=scala.io.Source.fromFile(path);val source=try file.mkString finally file.close()
 (new firrtl2.stage.FirrtlStage).execute(Array("-X","verilog","--target-dir","generated"),Seq(firrtl2.stage.FirrtlSourceAnnotation(source)))
}
