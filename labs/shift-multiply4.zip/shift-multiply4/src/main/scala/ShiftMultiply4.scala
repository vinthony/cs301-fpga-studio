package cs301
import chisel3._
import chisel3.util._
import scala.language.reflectiveCalls
/** Four rounds, unsigned operands. clear > load > enabled step. */
class ShiftMultiply4 extends Module {
 val io=IO(new Bundle{val clear=Input(Bool());val load=Input(Bool());val step=Input(Bool());val a=Input(UInt(4.W));val b=Input(UInt(4.W));val left=Output(UInt(8.W));val right=Output(UInt(4.W));val product=Output(UInt(8.W));val rounds=Output(UInt(3.W));val loaded=Output(Bool());val busy=Output(Bool());val done=Output(Bool())})
 val left=RegInit(0.U(8.W));val right=RegInit(0.U(4.W));val product=RegInit(0.U(8.W));val rounds=RegInit(0.U(3.W));val loaded=RegInit(false.B)
 when(io.clear){left:=0.U;right:=0.U;product:=0.U;rounds:=0.U;loaded:=false.B}
 .elsewhen(io.load){left:=io.a;right:=io.b;product:=0.U;rounds:=0.U;loaded:=true.B}
 .elsewhen(io.step && loaded && rounds<4.U){product:=product+Mux(right(0),left,0.U);left:=left<<1;right:=right>>1;rounds:=rounds+1.U}
 io.left:=left;io.right:=right;io.product:=product;io.rounds:=rounds;io.loaded:=loaded;io.busy:=loaded && rounds<4.U;io.done:=loaded && rounds===4.U
}
