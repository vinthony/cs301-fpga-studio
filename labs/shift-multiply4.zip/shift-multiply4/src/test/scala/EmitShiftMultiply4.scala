package cs301
object EmitShiftMultiply4 extends App {
 val path="test_run_dir/ShiftMultiply4_should_check_all_products_and_each_partial_result/ShiftMultiply4.lo.fir"
 require(new java.io.File(path).isFile,"Run test first")
 val file=scala.io.Source.fromFile(path);val source=try file.mkString finally file.close()
 (new firrtl2.stage.FirrtlStage).execute(Array("-X","verilog","--target-dir","generated"),Seq(firrtl2.stage.FirrtlSourceAnnotation(source)))
}
