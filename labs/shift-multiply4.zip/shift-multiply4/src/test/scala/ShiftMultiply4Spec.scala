package cs301
import chisel3._
import chiseltest._
import org.scalatest.flatspec.AnyFlatSpec
import scala.language.reflectiveCalls
class ShiftMultiply4Spec extends AnyFlatSpec with ChiselScalatestTester {
 behavior of "ShiftMultiply4"
 it should "check all products and each partial result" in {test(new ShiftMultiply4).withAnnotations(Seq(WriteVcdAnnotation)){c=>
  c.io.clear.poke(false.B);c.io.step.poke(false.B);c.io.load.poke(false.B);c.io.a.poke(0.U);c.io.b.poke(0.U)
  for(a<-0 until 16;b<-0 until 16){
   c.io.a.poke(a.U);c.io.b.poke(b.U);c.io.load.poke(true.B);c.clock.step();c.io.load.poke(false.B)
   for(k<-0 to 4){
    c.io.product.expect((a*(b% (1<<k))).U);c.io.left.expect(((a*(1<<k))&255).U);c.io.right.expect((b>>k).U);c.io.rounds.expect(k.U);c.io.busy.expect((k<4).B);c.io.done.expect((k==4).B)
    c.io.a.poke((15-a).U);c.io.b.poke((15-b).U);c.io.step.poke(false.B);c.clock.step();c.io.rounds.expect(k.U)
    if(k<4){c.io.step.poke(true.B);c.clock.step()}
   }
   c.io.step.poke(true.B);c.clock.step(2);c.io.product.expect((a*b).U);c.io.rounds.expect(4.U)
  }
 }}
 it should "restart and clear with explicit priority" in {test(new ShiftMultiply4){c=>
  c.io.a.poke(13.U);c.io.b.poke(11.U);c.io.step.poke(true.B);c.io.load.poke(true.B);c.io.clear.poke(false.B);c.clock.step();c.io.product.expect(0.U);c.io.rounds.expect(0.U)
  c.io.load.poke(false.B);c.clock.step();c.io.product.expect(13.U)
  c.io.a.poke(3.U);c.io.b.poke(5.U);c.io.load.poke(true.B);c.clock.step();c.io.product.expect(0.U);c.io.left.expect(3.U);c.io.right.expect(5.U);c.io.rounds.expect(0.U)
  c.io.clear.poke(true.B);c.clock.step();c.io.loaded.expect(false.B);c.io.product.expect(0.U);c.io.busy.expect(false.B);c.io.done.expect(false.B)
 }}
}
