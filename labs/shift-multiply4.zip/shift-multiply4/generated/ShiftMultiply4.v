module ShiftMultiply4( // @[src/main/scala/ShiftMultiply4.scala 6:7]
  input        clock, // @[src/main/scala/ShiftMultiply4.scala 6:7]
  input        reset, // @[src/main/scala/ShiftMultiply4.scala 6:7]
  input        io_clear, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  input        io_load, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  input        io_step, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  input  [3:0] io_a, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  input  [3:0] io_b, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output [7:0] io_left, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output [3:0] io_right, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output [7:0] io_product, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output [2:0] io_rounds, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output       io_loaded, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output       io_busy, // @[src/main/scala/ShiftMultiply4.scala 7:11]
  output       io_done // @[src/main/scala/ShiftMultiply4.scala 7:11]
);
`ifdef RANDOMIZE_REG_INIT
  reg [31:0] _RAND_0;
  reg [31:0] _RAND_1;
  reg [31:0] _RAND_2;
  reg [31:0] _RAND_3;
  reg [31:0] _RAND_4;
`endif // RANDOMIZE_REG_INIT
  reg [7:0] left; // @[src/main/scala/ShiftMultiply4.scala 8:18]
  reg [3:0] right; // @[src/main/scala/ShiftMultiply4.scala 8:46]
  reg [7:0] product; // @[src/main/scala/ShiftMultiply4.scala 8:76]
  reg [2:0] rounds; // @[src/main/scala/ShiftMultiply4.scala 8:105]
  reg  loaded; // @[src/main/scala/ShiftMultiply4.scala 8:134]
  wire  _T_1 = rounds < 3'h4; // @[src/main/scala/ShiftMultiply4.scala 11:39]
  wire [7:0] _product_T_1 = right[0] ? left : 8'h0; // @[src/main/scala/ShiftMultiply4.scala 11:65]
  wire [7:0] _product_T_3 = product + _product_T_1; // @[src/main/scala/ShiftMultiply4.scala 11:61]
  wire [8:0] _left_T = {left, 1'h0}; // @[src/main/scala/ShiftMultiply4.scala 11:95]
  wire [2:0] _rounds_T_1 = rounds + 3'h1; // @[src/main/scala/ShiftMultiply4.scala 11:129]
  wire [8:0] _GEN_1 = io_step & loaded & rounds < 3'h4 ? _left_T : {{1'd0}, left}; // @[src/main/scala/ShiftMultiply4.scala 11:{44,89} 8:18]
  wire [8:0] _GEN_4 = io_load ? {{5'd0}, io_a} : _GEN_1; // @[src/main/scala/ShiftMultiply4.scala 10:{20,25}]
  wire  _GEN_8 = io_load | loaded; // @[src/main/scala/ShiftMultiply4.scala 10:{20,75} 8:134]
  wire [8:0] _GEN_9 = io_clear ? 9'h0 : _GEN_4; // @[src/main/scala/ShiftMultiply4.scala 9:{16,21}]
  wire [8:0] _GEN_14 = reset ? 9'h0 : _GEN_9; // @[src/main/scala/ShiftMultiply4.scala 8:{18,18}]
  assign io_left = left; // @[src/main/scala/ShiftMultiply4.scala 12:9]
  assign io_right = right; // @[src/main/scala/ShiftMultiply4.scala 12:24]
  assign io_product = product; // @[src/main/scala/ShiftMultiply4.scala 12:42]
  assign io_rounds = rounds; // @[src/main/scala/ShiftMultiply4.scala 12:61]
  assign io_loaded = loaded; // @[src/main/scala/ShiftMultiply4.scala 12:79]
  assign io_busy = loaded & _T_1; // @[src/main/scala/ShiftMultiply4.scala 12:104]
  assign io_done = loaded & rounds == 3'h4; // @[src/main/scala/ShiftMultiply4.scala 12:134]
  always @(posedge clock) begin
    left <= _GEN_14[7:0]; // @[src/main/scala/ShiftMultiply4.scala 8:{18,18}]
    if (reset) begin // @[src/main/scala/ShiftMultiply4.scala 8:{46,46}]
      right <= 4'h0;
    end else if (io_clear) begin // @[src/main/scala/ShiftMultiply4.scala 9:{16,32}]
      right <= 4'h0;
    end else if (io_load) begin // @[src/main/scala/ShiftMultiply4.scala 10:{20,37}]
      right <= io_b;
    end else if (io_step & loaded & rounds < 3'h4) begin // @[src/main/scala/ShiftMultiply4.scala 11:104]
      right <= {{1'd0}, right[3:1]}; // @[src/main/scala/ShiftMultiply4.scala 11:44]
    end
    if (reset) begin // @[src/main/scala/ShiftMultiply4.scala 8:{76,76}]
      product <= 8'h0;
    end else if (io_clear) begin // @[src/main/scala/ShiftMultiply4.scala 9:{16,45}]
      product <= 8'h0;
    end else if (io_load) begin // @[src/main/scala/ShiftMultiply4.scala 10:{20,51}]
      product <= 8'h0;
    end else if (io_step & loaded & rounds < 3'h4) begin // @[src/main/scala/ShiftMultiply4.scala 11:44]
      product <= _product_T_3; // @[src/main/scala/ShiftMultiply4.scala 11:52]
    end
    if (reset) begin // @[src/main/scala/ShiftMultiply4.scala 8:{105,105}]
      rounds <= 3'h0;
    end else if (io_clear) begin // @[src/main/scala/ShiftMultiply4.scala 9:{16,57}]
      rounds <= 3'h0;
    end else if (io_load) begin // @[src/main/scala/ShiftMultiply4.scala 10:{20,63}]
      rounds <= 3'h0;
    end else if (io_step & loaded & rounds < 3'h4) begin // @[src/main/scala/ShiftMultiply4.scala 11:121]
      rounds <= _rounds_T_1; // @[src/main/scala/ShiftMultiply4.scala 11:44]
    end
    if (reset) begin // @[src/main/scala/ShiftMultiply4.scala 8:{134,134}]
      loaded <= 1'h0;
    end else if (io_clear) begin // @[src/main/scala/ShiftMultiply4.scala 9:{16,69}]
      loaded <= 1'h0;
    end else begin
      loaded <= _GEN_8;
    end
  end
// Register and memory initialization
`ifdef RANDOMIZE_GARBAGE_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_INVALID_ASSIGN
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_REG_INIT
`define RANDOMIZE
`endif
`ifdef RANDOMIZE_MEM_INIT
`define RANDOMIZE
`endif
`ifndef RANDOM
`define RANDOM $random
`endif
`ifdef RANDOMIZE_MEM_INIT
  integer initvar;
`endif
`ifndef SYNTHESIS
`ifdef FIRRTL_BEFORE_INITIAL
`FIRRTL_BEFORE_INITIAL
`endif
initial begin
  `ifdef RANDOMIZE
    `ifdef INIT_RANDOM
      `INIT_RANDOM
    `endif
    `ifndef VERILATOR
      `ifdef RANDOMIZE_DELAY
        #`RANDOMIZE_DELAY begin end
      `else
        #0.002 begin end
      `endif
    `endif
`ifdef RANDOMIZE_REG_INIT
  _RAND_0 = {1{`RANDOM}};
  left = _RAND_0[7:0];
  _RAND_1 = {1{`RANDOM}};
  right = _RAND_1[3:0];
  _RAND_2 = {1{`RANDOM}};
  product = _RAND_2[7:0];
  _RAND_3 = {1{`RANDOM}};
  rounds = _RAND_3[2:0];
  _RAND_4 = {1{`RANDOM}};
  loaded = _RAND_4[0:0];
`endif // RANDOMIZE_REG_INIT
  `endif // RANDOMIZE
end // initial
`ifdef FIRRTL_AFTER_INITIAL
`FIRRTL_AFTER_INITIAL
`endif
`endif // SYNTHESIS
endmodule
