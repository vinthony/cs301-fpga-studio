# GBU-CS301：四轮移位相加乘法器

对应教学板 `multiply4` 页面，四位无符号输入、八位保存结果。下载包含Chisel源码、生成Verilog、测试、VCD、独立数学参考及证据。

## 行为

- 一个主时钟；同步 `reset` / `clear` 最高优先，全部保存量清零并使loaded=false。
- `load` 次优先，可在忙时重新开始：捕获A/B，部分积P清零，轮数清零，loaded=true。
- `step` 且已装载且轮数<4时执行一轮：按右移乘数最低位决定是否将当前左移被乘数加入P；同一边沿提交P、左移值、右移值和轮数。
- `step=0`保持；轮数=4后继续step不重复执行。
- busy=loaded且轮数<4，done=loaded且轮数=4；done是保持电平，直到重新装载或清零，不是单拍脉冲。
- product在busy期间是已保存部分积，不能提前当成最终结果。零操作数也执行四轮，未实现提前结束优化。
- 26位可观测状态包括left8、right4、product8、rounds3、loaded/busy/done各1位。

## 运行

需要JDK17/21；run.sh下载并校验本工程本地sbt启动器，不修改全局环境。

```sh
chmod +x run.sh
./run.sh test 'Test / runMain cs301.EmitShiftMultiply4'
python3 verification/check_generated.py
```

Python复验需要PATH中有Icarus Verilog的iverilog/vvp。Verilog从实际测试后的lo.fir经JVM FIRRTL后端导出，不依赖本机firtool。

独立参考不执行条件累加算法，而使用闭式数学式：第k轮后P=a×(b mod 2^k)、left=(a×2^k) mod 256、right=floor(b/2^k)。向量包含全部256组、6种保存阶段×16组控制优先级、20000步随机输入；实际生成RTL通过23249个边沿后和23248个边沿前26位快照。

网页使用同参考向量对照46497项。主教学板工程中运行：

```sh
node tests/multiply4_rtl_match.cjs /path/to/shift-multiply4/out/vectors.hex
```

out由复验生成，不随下载包提供。网页的装载重置教学轮数计数；step=0映射为不调用网页轮次，不比较暂停墙钟时间。网页动画前两阶段只讲解，第三阶段才对应一个实际step边沿。

## 文件与边界

两项Chisel测试覆盖256组全部部分积、输入改变不污染捕获值、暂停、完成保持，以及重新装载/清零优先级。VCD位于evidence/ShiftMultiply4.vcd。

这是四位无符号多周期教学电路，不是有符号乘法、DSP内部物理阵列、CPU M扩展或完整处理器。没有实体引脚、时序约束、STA、资源映射/Fmax或板上验证。八位结果足以保存15×15=225；不能把本工程宽度直接扩展为任意位宽。
