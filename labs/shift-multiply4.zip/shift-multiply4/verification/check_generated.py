#!/usr/bin/env python3
"""Closed-form partial products, independent of iterative add/shift implementation."""
from pathlib import Path
import json,random,subprocess
BASE=Path(__file__).resolve().parents[1];OUT=BASE/'out';OUT.mkdir(exist_ok=True)
a=b=k=0;loaded=False;vectors=[]
def pack():
 left=(a*2**k)&255;right=b//2**k;product=a*(b%2**k)
 return left<<18|right<<14|product<<6|k<<3|int(loaded)<<2|int(loaded and k<4)<<1|int(loaded and k==4)
def add(x=0,y=0,step=0,load=0,clear=0,reset=0):
 global a,b,k,loaded
 before=pack()
 if clear or reset:a=b=k=0;loaded=False
 elif load:a=x;b=y;k=0;loaded=True
 elif step and loaded and k<4:k+=1
 after=pack();control=x<<12|y<<8|reset<<3|clear<<2|load<<1|step
 vectors.append(f'{control:04x}{before:07x}{after:07x}')
add(reset=1)
for phase in [-1,0,1,2,3,4]:
 for controls in range(16):
  add(clear=1)
  if phase>=0:
   add(x=13,y=11,load=1)
   for _ in range(phase):add(step=1)
  add(x=3,y=5,step=controls&1,load=(controls>>1)&1,clear=(controls>>2)&1,reset=(controls>>3)&1)
for x in range(16):
 for y in range(16):
  add(x=x,y=y,load=1)
  for round in range(4):add(x=15-x,y=15-y,step=0);add(step=1)
  add(step=1);add(step=0)
rng=random.Random(3014)
for i in range(20000):add(rng.randrange(16),rng.randrange(16),rng.randrange(2),int(i%13==0),int(i%113==0),int(i%271==0))
(OUT/'vectors.hex').write_text('\n'.join(vectors)+'\n')
tb='''module tb;
reg clock=0,reset=0,step=0,load=0,clear=0;reg[3:0]a=0,b=0;
wire[7:0]left,product;wire[3:0]right;wire[2:0]rounds;wire loaded,busy,done;
wire[27:0]actual={2'b0,left,right,product,rounds,loaded,busy,done};
ShiftMultiply4 dut(.clock(clock),.reset(reset),.io_clear(clear),.io_load(load),.io_step(step),.io_a(a),.io_b(b),.io_left(left),.io_right(right),.io_product(product),.io_rounds(rounds),.io_loaded(loaded),.io_busy(busy),.io_done(done));
reg[71:0]vectors[0:COUNT-1];integer i;
initial begin
 $readmemh("vectors.hex",vectors);
 for(i=0;i<COUNT;i=i+1)begin
  a=vectors[i][71:68];b=vectors[i][67:64];{reset,clear,load,step}=vectors[i][59:56];#5;
  if(i>0 && actual!==vectors[i][55:28])begin $display("FAIL PRE %0d %h %h",i,actual,vectors[i][55:28]);$fatal;end
  clock=1;#1;
  if(actual!==vectors[i][27:0])begin $display("FAIL POST %0d %h %h",i,actual,vectors[i][27:0]);$fatal;end
  #4;clock=0;
 end
 $display("PASS COUNT edges");$finish;
end
endmodule
'''.replace('COUNT',str(len(vectors)))
(OUT/'tb.v').write_text(tb);subprocess.run(['iverilog','-g2012','-s','tb','-o','sim',str(BASE/'generated/ShiftMultiply4.v'),'tb.v'],cwd=OUT,check=True)
run=subprocess.run(['vvp','sim'],cwd=OUT,text=True,capture_output=True,check=True)
report=dict(status='passed',postEdgeSnapshots=len(vectors),preEdgeSnapshots=len(vectors)-1,packedBits=26,products=256,coverage='all products with paused inputs and done hold; 6 saved stages x 16 priority controls; 20000 random controls',reference='closed-form a*(b mod 2^k), a*2^k and floor(b/2^k)',stdout=run.stdout.strip())
(BASE/'evidence/generated-rtl-check.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
